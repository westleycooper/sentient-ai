# Sentinel

Configurable, multi-reasoning voice agent platform. Speak -> STT -> multi-step
LangGraph reasoning with persistent Postgres context -> TTS. Reasoning steps and
subject-matter expertise (SME) are user-configurable from one page; domain drives
generated frontend types + hooks. Minimal UI: Three.js waveform + mic button, with
a slide-out chat transcript.

## Start here
1. **Read `CLAUDE.md`** — the standards/context investment doc. Everything downstream depends on it.
2. `REVIEW.md` — the PR review rubric.
3. `docs/standards/` — DDD, RAG, Azure, security, observability, testing, stack versions.
4. `docs/adr/` — architecture decisions.

## Layout
- `packages/domain` — SME bounded-context definitions (source of truth; FTSE100 default included)
- `packages/contracts` — committed OpenAPI/JSON Schema + generated types & TanStack Query hooks
- `apps/api` — FastAPI + LangGraph (domain / application / infrastructure / interface layers)
- `apps/web` — React 19 + Vite + MUI v9 + TanStack Query + Zustand; Three.js waveform
- `infra/bicep` — pure IaC for Azure (cloud-agnostic app)

## Custom Claude Code commands
`/new-sme`, `/new-service`, `/adr`, `/review`, `/regen-contracts`, `/check-boundaries`, `/pii-check`.

## Build order (suggested for Claude Code)
1. Confirm `CLAUDE.md` matches your intent; adjust.
2. `/new-service` to flesh out the conversation use case + ports + adapters.
3. Wire the FastAPI interface + SSE step stream; `/regen-contracts`.
4. Build the web shell (waveform + mic + drawer + single config page).
5. `infra/bicep` to your subscription; CI for lint/types/tests/coverage/boundary/bicep build.
